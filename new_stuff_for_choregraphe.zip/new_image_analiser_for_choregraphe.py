########### Python 2.7 #############
import httplib, urllib, json


def analise_text(input_text, key_ling = "2eff9ce5e0424f07be62552b361ce1ae"):
    headers = {
        # Request headers
        'Content-Type': 'application/json',
        'Ocp-Apim-Subscription-Key': key_ling,
    }

    data = {
        "language" : "en",
        "analyzerIds" : ["4fa79af1-f22c-408d-98bb-b7d7aeef7f04"],
        "text" : input_text,
        }

    params = urllib.urlencode({
    })

    req_url = 'westus.api.cognitive.microsoft.com'

    try:
        conn = httplib.HTTPSConnection(req_url)
        conn.request("POST", "/linguistics/v1.0/analyze?%s" % params, body=json.dumps(data), headers=headers)
        response = conn.getresponse()
        data = response.read()
        conn.close()
    except Exception as e:
        print("[Errno {0}] {1}".format(e.errno, e.strerror))

    return data

def analise_image(image_file, key_vision = "64b944fcc2e54619921d896b9db02fd9"):
    with open(image_file, 'rb') as f:
        image_data = f.read()


    headers = {
        # Request headers
        'Content-Type': 'application/octet-stream',
        'Ocp-Apim-Subscription-Key': key_vision,
    }

    params = urllib.urlencode({
        # Request parameters
        'visualFeatures': 'Tags,Description,Categories',
        'language': 'en',
    })

    req_url = 'westus.api.cognitive.microsoft.com'

    try:
        conn = httplib.HTTPSConnection(req_url)
        conn.request("POST", "/vision/v1.0/analyze?%s" % params, body=image_data, headers=headers)
        response = conn.getresponse()
        data = response.read()
        conn.close()
    except Exception as e:
        print("[Errno {0}] {1}".format(e.errno, e.strerror))

    return data


def check_tags(response, min_conf=0.5):

    sentence = []
    for tag in json.loads(response)['tags']:
        if tag['confidence']>min_conf:
            sentence.append(tag['name'])

    return sentence

def test():
    # /var/www/apps/.lastUploadedChoregrapheBehavior/html/image.jpg
    # or
    # /var/www/apps/marta_app/html/image.jpg
    resp=analise_image("image_test.png")
    s = check_tags(resp)
    an = json.loads(analise_text(" ".join(s)))[0]['result'][0]
    selected = []
    for i,res in enumerate(an):
        if res[:2]=='NN':
            selected.append(s[i])
    return selected

print "Nouns:"+str(test())

# " ".join(s)
